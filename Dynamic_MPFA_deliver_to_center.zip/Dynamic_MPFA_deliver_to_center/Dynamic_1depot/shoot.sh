argos3 -c experiments/iAnt_mac.argos
